import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import "../styles/themeSwitch.css";

export default function ThemeSwitch() {
    const { t } = useTranslation();
    const [checked, setChecked] = useState(false);

    useEffect(() => {
        const root = document.documentElement;
        if (checked) {
            root.setAttribute("data-theme", "alt");
        } else {
            root.removeAttribute("data-theme");
        }
    }, [checked]);

    return (
        <label className="switch">
            <input
                type="checkbox"
                checked={checked}
                onChange={() => setChecked(!checked)}
            />
            <span className="slider"></span>
        </label>
    );
}